# Dangerous Liaisons data visualization project

To get started, you need to ensure that you have NPM and Node **>=20.0.0** running on your machine. Install the dependencies (npm install) and then run the project locally (npm run serve):

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
